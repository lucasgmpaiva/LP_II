public class Main{

	public static void main(String[] args) {
		BallDemo demoBall = new BallDemo();
		demoBall.bounce();
	}
}